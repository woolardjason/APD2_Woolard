package com.jasonwoolard.geoshare;
import com.parse.ParseClassName;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseUser;

@ParseClassName("Sales")
public class Sale extends ParseObject {
 
    public Sale() {
    }
 
    public String getTitle() {
        return getString("title");
    }
 
    public void setTitle(String title) {
        put("title", title);
    }
 
    public String getPostedBy() {
        return getString("postedBy");
    }
 
    public void setPostedBy(ParseUser user) {
        String username = user.getUsername().toString();
        put("postedBy", username);
    }
 
    public String getPrice() {
        return getString("price");
    }
 
    public void setPrice(String price) {
        put("price", price);
    }
    public String getLocation() {
        return getString("location");
    }
 
    public void setLocation(String location) {
        put("location", location);
    }
    public String getDescription() {
        return getString("description");
    }
 
    public void setDescription(String description) {
        put("description", description);
    }
    public String getObjectId() {
        return getString("objectId");
    }
 
    public ParseFile getPhotoFile() {
        return getParseFile("photo");
    }
   
 
    public void setPhotoFile(ParseFile file) {
        put("photo", file);
    }
 
}
