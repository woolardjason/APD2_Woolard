package com.jasonwoolard.geoshare;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.jasonwoolard.geoshare.libs.FileHelper;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseImageView;
import com.parse.ParseUser;
import com.parse.SaveCallback;

public class PostSaleFragment extends Fragment {
	
	Button mPostSaleBtn;
	EditText mItemTitle;
	EditText mItemPrice;
	EditText mItemLocation;
	EditText mItemDescription;
	EditText mCaptchaInput;
	TextView mCaptchaCode;
	ParseUser mUser;
	String mCurrentUser;
	Button mSnapPhoto;
	Uri mUri;
	
	private ParseImageView mSalePreview;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		View v = inflater.inflate(R.layout.activity_post_sale, container, false);

		initializeUIElements(v);
		mSnapPhoto.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent snapPhotoIntent = new Intent (MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(snapPhotoIntent, 0);
			}
		});
		mPostSaleBtn.setOnClickListener(new View.OnClickListener() {
		
			
			@SuppressLint("NewApi")
			@Override
			public void onClick(View v) {
				// Obtaining inputed information from user, removing any whitespace in the process.
				 String itemTitle = mItemTitle.getText().toString().trim();
				 String itemPrice = mItemPrice.getText().toString().trim();
				 String itemLocation = mItemLocation.getText().toString().trim();
				 String itemDescription = mItemDescription.getText().toString().trim();
				 String captchaInput = mCaptchaInput.getText().toString().trim();
				
				// Checking EditText fields for empty values, if they are return an alert dialog for the user.
				if (itemTitle.isEmpty() || itemPrice.isEmpty() || itemLocation.isEmpty() || itemDescription.isEmpty() || captchaInput.isEmpty())
				{
					AlertDialog.Builder b = new AlertDialog.Builder(getActivity());
					b.setMessage(R.string.error_message_sign_up_missing_field);
					b.setTitle(R.string.error_title_sign_up_missing_field);
					b.setPositiveButton(android.R.string.ok, null);
					AlertDialog d = b.create();
					d.show();
				}
				else
				{
					
				Sale sale = ((PostSaleActivity) getActivity()).getCurrentSale();

				sale.setTitle(itemTitle);

				sale.setPostedBy(ParseUser.getCurrentUser());

				sale.setPrice("$"+itemPrice);
				sale.setLocation(itemLocation);
				sale.setDescription(itemDescription);
				byte[] fileBytes = FileHelper.getByteArrayFromFile(getActivity().getApplicationContext(), mUri);
				if (fileBytes != null)
				{
				fileBytes = FileHelper.reduceImageForUpload(fileBytes);
				String fileName = FileHelper.getFileName(getActivity().getApplicationContext(), mUri, "image");
				ParseFile file = new ParseFile(fileName, fileBytes);
				sale.setPhotoFile(file);
				}
				

				sale.saveInBackground(new SaveCallback() {

					@Override
					public void done(ParseException e) {
						if (e == null) {
							getActivity().setResult(Activity.RESULT_OK);
							getActivity().finish();
							Toast.makeText(getActivity().getApplicationContext(), "Your item has been posted for sale successfully!", Toast.LENGTH_LONG).show();

						} else {
							Toast.makeText(
									getActivity().getApplicationContext(),
									"Error saving: " + e.getMessage(),
									Toast.LENGTH_SHORT).show();
						}
					}

				});
				}
			}
		});
		return v;
	}

	public void initializeUIElements(View v) {
		mPostSaleBtn = (Button) v.findViewById(R.id.button_post_sale);
		mItemTitle = (EditText) v.findViewById(R.id.editText_item_title);
		mItemPrice = (EditText) v.findViewById(R.id.editText_item_price);
		mItemLocation = (EditText) v.findViewById(R.id.editText_item_location);
		mItemDescription = (EditText) v.findViewById(R.id.editText_item_description);
		mCaptchaInput = (EditText) v.findViewById(R.id.editText_captcha_input);
		mSalePreview = (ParseImageView) v.findViewById(R.id.sale_image);
		mCaptchaCode = (TextView) v.findViewById(R.id.textView_captcha_code);
		mSnapPhoto = (Button) v.findViewById(R.id.button_snapPhoto);
	}

	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == Activity.RESULT_OK )
		{
			if (requestCode == 0)
			{
				if (data != null)
				{
					mUri = data.getData();
				}
				else
				{
					Toast.makeText(getActivity().getApplicationContext(), "There has been an error!",
							   Toast.LENGTH_LONG).show();					
				}
			}
		}
	}

}
